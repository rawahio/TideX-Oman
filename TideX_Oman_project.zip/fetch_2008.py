import argparse
import os
import re
import shutil
import tempfile

import earthaccess
import xarray as xr

LAT_MIN, LAT_MAX = 16.0, 26.6
LON_MIN, LON_MAX = 53.0, 60.6
OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "replay_2008")

PRODUCTS = {
    "chl": ("MODISA_L3m_CHL", ".L3m.DAY.CHL.chlor_a.4km.nc", "chlor_a"),
    "sst": ("MODISA_L3m_SST", ".L3m.DAY.SST.sst.4km.nc", "sst"),
}


def subset(src, dst, var):
    with xr.open_dataset(src) as ds:
        lat_slice = slice(LAT_MAX, LAT_MIN) if ds.lat[0] > ds.lat[-1] else slice(LAT_MIN, LAT_MAX)
        small = ds[[var]].sel(lat=lat_slice, lon=slice(LON_MIN, LON_MAX)).load()
        small.attrs["time_coverage_start"] = ds.attrs.get("time_coverage_start", "")
    small.to_netcdf(dst, encoding={var: {"zlib": True, "complevel": 4}})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true")
    args = parser.parse_args()
    start, end = ("2008-11-01", "2008-11-03") if args.test else ("2008-10-01", "2008-12-31")

    os.makedirs(OUT_DIR, exist_ok=True)
    auth = earthaccess.login(strategy="netrc")
    if not auth.authenticated:
        raise SystemExit("Login failed.")

    for key, (short_name, ending, var) in PRODUCTS.items():
        print(f"\n=== {key.upper()}: searching {short_name} {start} -> {end}")
        results = earthaccess.search_data(short_name=short_name, temporal=(start, end))
        wanted = {}
        for g in results:
            for link in g.data_links():
                if link.endswith(ending):
                    m = re.search(r"\.(\d{8})\.L3m", link)
                    if m and m.group(1) not in wanted:
                        wanted[m.group(1)] = g
        print(f"found {len(wanted)} daily files")

        for i, (date, granule) in enumerate(sorted(wanted.items()), 1):
            dst = os.path.join(OUT_DIR, f"{key}_{date}.nc")
            if os.path.exists(dst):
                print(f"[{i}/{len(wanted)}] {date} already done")
                continue
            tmp = tempfile.mkdtemp()
            try:
                paths = earthaccess.download([granule], local_path=tmp, show_progress=False)
                src = next(str(p) for p in paths if str(p).endswith(ending))
                subset(src, dst, var)
                print(f"[{i}/{len(wanted)}] {date} saved ({os.path.getsize(dst) // 1024} KB)")
            except Exception as e:
                print(f"[{i}/{len(wanted)}] {date} FAILED: {e}")
            finally:
                shutil.rmtree(tmp, ignore_errors=True)

    print(f"\nDone. Files are in: {OUT_DIR}")


if __name__ == "__main__":
    main()