"""
TideX Oman — Early warning for harmful algal blooms near Omani desalination plants.
Streamlit app: simulated demo mode + real NASA NetCDF mode (chlorophyll-a & SST).
"""
import datetime
import os
import smtplib
import tempfile
from email.message import EmailMessage

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
import xarray as xr
from fpdf import FPDF
from fpdf.fonts import FontFace
from global_land_mask import globe

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FONT_REGULAR = os.path.join(BASE_DIR, "fonts", "ReadexPro-Regular.ttf")
FONT_BOLD = os.path.join(BASE_DIR, "fonts", "ReadexPro-SemiBold.ttf")

# Study area (Omani waters: Sea of Oman + Arabian Sea)
LAT_MIN, LAT_MAX = 16.0, 26.6
LON_MIN, LON_MAX = 53.0, 60.6
REGION_SPLIT_LAT = 22.4          # Ras al Hadd: north = Sea of Oman, south = Arabian Sea
CRITICAL_KM, WARNING_KM = 20, 50

# ---------------------------------------------------------------------------
# 1. Page setup & language
# ---------------------------------------------------------------------------
st.set_page_config(page_title="TideX Oman", page_icon="🌊", layout="wide")

lang = st.sidebar.radio("🌐 Language / اللغة", ["العربية", "English"])
AR = lang == "العربية"


def t(ar, en):
    return ar if AR else en


if AR:
    st.markdown("""
    <style>
    [data-testid="stMarkdownContainer"], [data-testid="stSidebar"], .stAlert,
    [data-testid="stMetric"], h1, h2, h3 {direction: rtl; text-align: right;}
    </style>""", unsafe_allow_html=True)

st.markdown(f"""
<div style="background:#0e1117;padding:16px 20px;border-radius:10px;margin-bottom:18px;">
  <h1 style="color:#00d4ff;margin:0;">🌊 TideX Oman</h1>
  <p style="color:#a0aab2;margin:4px 0 0 0;">{t(
      "نظام الإنذار المبكر لحماية محطات تحلية المياه في سلطنة عُمان من المد الأحمر — باستخدام بيانات الأقمار الصناعية لوكالة ناسا",
      "Early warning of harmful algal blooms for Oman's desalination plants — powered by NASA satellite data")}</p>
</div>""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# 2. Desalination plants (approximate coastal locations)
# ---------------------------------------------------------------------------
PLANTS = pd.DataFrame([
    {"ar": "محطة الغبرة (مسقط)", "en": "Al Ghubrah (Muscat)", "lat": 23.60, "lon": 58.42},
    {"ar": "محطة بركاء",          "en": "Barka",              "lat": 23.70, "lon": 57.88},
    {"ar": "محطة صحار",           "en": "Sohar",              "lat": 24.45, "lon": 56.63},
    {"ar": "محطة صور",            "en": "Sur",                "lat": 22.57, "lon": 59.52},
    {"ar": "محطة الدقم",          "en": "Duqm",               "lat": 19.66, "lon": 57.71},
    {"ar": "محطة صلالة",          "en": "Salalah",            "lat": 16.98, "lon": 54.10},
])
PLANTS["name"] = PLANTS["ar"] if AR else PLANTS["en"]


def haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance (km). Works on scalars or numpy arrays."""
    r = 6371.0
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dphi, dlmb = p2 - p1, np.radians(lon2 - lon1)
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dlmb / 2) ** 2
    return 2 * r * np.arctan2(np.sqrt(a), np.sqrt(1 - a))


def risk_score(chl, sst, growth):
    """
    Composite risk score, 0–200:
      chlorophyll-a : up to 120 pts (1 → 10 mg/m³)
      sea temp (SST): up to  50 pts (27 → 31 °C)
      7-day growth  : up to  30 pts (0 → 100 %)
    """
    chl_pts = 120 * np.clip((chl - 1.0) / 9.0, 0, 1)
    sst_pts = 50 * np.clip((np.nan_to_num(sst, nan=27.0) - 27.0) / 4.0, 0, 1)
    gr_pts = 30 * np.clip(np.nan_to_num(growth, nan=0.0) / 100.0, 0, 1)
    return np.round(chl_pts + sst_pts + gr_pts, 1)


def sea_only(df):
    keep = ~globe.is_land(df["lat"].to_numpy(), df["lon"].to_numpy())
    # drop the Arabian/Persian Gulf west of Musandam (outside Omani waters)
    keep &= ~((df["lat"] > 24.9) & (df["lon"] < 56.0))
    return df[keep].reset_index(drop=True)


# ---------------------------------------------------------------------------
# 3. Data sources
# ---------------------------------------------------------------------------
@st.cache_data
def simulated_data(day: int) -> pd.DataFrame:
    """Realistic demo field: background ocean + bloom patches drifting toward the coast."""
    rng = np.random.default_rng(42)
    lats = np.arange(LAT_MIN, LAT_MAX, 0.08)
    lons = np.arange(LON_MIN, LON_MAX, 0.08)
    lon_g, lat_g = np.meshgrid(lons, lats)
    lat_g, lon_g = lat_g.ravel(), lon_g.ravel()

    chl = rng.lognormal(mean=np.log(0.6), sigma=0.35, size=lat_g.size)
    growth = rng.uniform(-10, 15, size=lat_g.size)
    sst = 26.5 + (lat_g - LAT_MIN) * 0.22 + rng.normal(0, 0.4, lat_g.size)

    # (start lat, start lon, drift lat/day, drift lon/day, peak chl, radius km)
    blooms = [
        (23.95, 58.95, -0.06, -0.08, 14.0, 22),   # offshore Muscat, drifting to Al Ghubrah
        (22.95, 60.05, -0.04, -0.06, 9.0, 25),    # off Ras al Hadd, toward Sur
        (19.30, 58.60,  0.02, -0.10, 12.0, 45),   # Arabian Sea off Duqm
        (16.55, 54.70,  0.05, -0.04, 7.0, 30),    # off Salalah
    ]
    for lat0, lon0, dlat, dlon, peak, rad in blooms:
        clat, clon = lat0 + dlat * day, lon0 + dlon * day
        d = haversine_km(clat, clon, lat_g, lon_g)
        w = np.exp(-(d / rad) ** 2)
        chl += peak * w
        growth += 80 * w
        sst += 1.8 * w

    df = pd.DataFrame({
        "lat": np.round(lat_g, 3), "lon": np.round(lon_g, 3),
        "chlorophyll": np.round(chl, 2), "sst_temp": np.round(sst, 1),
        "growth_rate_pct": np.round(growth, 1),
    })
    return sea_only(df)


def _pick(ds, names):
    for n in names:
        if n in ds.variables:
            return n
    return None


def _open_nc(uploaded):
    with tempfile.NamedTemporaryFile(suffix=".nc", delete=False) as f:
        f.write(uploaded.getvalue())
        path = f.name
    return xr.open_dataset(path)


def _subset(da):
    lat_n = _pick(da.coords, ["lat", "latitude"])
    lon_n = _pick(da.coords, ["lon", "longitude"])
    da = da.rename({lat_n: "lat", lon_n: "lon"}).squeeze(drop=True)
    lat_slice = slice(LAT_MAX, LAT_MIN) if da.lat[0] > da.lat[-1] else slice(LAT_MIN, LAT_MAX)
    return da.sel(lat=lat_slice, lon=slice(LON_MIN, LON_MAX))


@st.cache_data
def nasa_data(chl_bytes, chl_name, prev_bytes, prev_name, sst_bytes, sst_name):
    """Read NASA Level-3 NetCDF (OB.DAAC chlor_a, optional GHRSST SST) into a point table."""
    class _U:  # tiny wrapper so cached bytes can reuse _open_nc
        def __init__(self, b): self.b = b
        def getvalue(self): return self.b

    ds = _open_nc(_U(chl_bytes))
    var = _pick(ds, ["chlor_a", "chl", "CHL", "chlor_a_mean"])
    if var is None:
        raise ValueError("No chlorophyll variable (chlor_a) found in file.")
    chl = _subset(ds[var])
    step = max(1, int(round(0.08 / abs(float(chl.lat[1] - chl.lat[0])))))
    chl = chl.coarsen(lat=step, lon=step, boundary="trim").mean()
    date = str(ds.attrs.get("time_coverage_start", ""))[:10] or chl_name

    out = chl.to_dataframe(name="chlorophyll").reset_index()[["lat", "lon", "chlorophyll"]]

    if sst_bytes:
        sds = _open_nc(_U(sst_bytes))
        svar = _pick(sds, ["analysed_sst", "sst", "SST", "sea_surface_temperature"])
        sst = _subset(sds[svar]).interp(lat=chl.lat, lon=chl.lon, method="nearest")
        if float(sst.mean(skipna=True)) > 200:      # Kelvin → °C
            sst = sst - 273.15
        out["sst_temp"] = np.round(sst.values.ravel(), 1)
    else:
        out["sst_temp"] = np.nan

    if prev_bytes:
        pds = _open_nc(_U(prev_bytes))
        prev = _subset(pds[_pick(pds, ["chlor_a", "chl", "CHL", "chlor_a_mean"])])
        prev = prev.interp(lat=chl.lat, lon=chl.lon, method="nearest").values.ravel()
        out["growth_rate_pct"] = np.round((out["chlorophyll"] - prev) / prev * 100, 1)
    else:
        out["growth_rate_pct"] = np.nan

    out = out.dropna(subset=["chlorophyll"])          # clouds / no-data pixels
    out["chlorophyll"] = out["chlorophyll"].round(2)
    return sea_only(out), date


# ---------------------------------------------------------------------------
# 3b. Historical replay (2008 red tide) — files made by fetch_2008.py
# ---------------------------------------------------------------------------
REPLAY_DIR = os.path.join(BASE_DIR, "data", "replay_2008")


def replay_available():
    return os.path.isdir(REPLAY_DIR) and any(f.startswith("chl_") for f in os.listdir(REPLAY_DIR))


@st.cache_data(show_spinner="Loading 2008 NASA archive…")
def load_replay():
    """Daily chl & SST stacks (time, lat, lon) on a ~8 km grid + sea mask."""
    dates = sorted(f[4:12] for f in os.listdir(REPLAY_DIR) if f.startswith("chl_") and f.endswith(".nc"))
    chl_list, sst_list, lat, lon = [], [], None, None
    for d in dates:
        with xr.open_dataset(os.path.join(REPLAY_DIR, f"chl_{d}.nc")) as ds:
            c = ds["chlor_a"].coarsen(lat=2, lon=2, boundary="trim").mean().load()
        if lat is None:
            lat, lon = c.lat.values.astype(float), c.lon.values.astype(float)
        chl_list.append(c.values)
        sst_path = os.path.join(REPLAY_DIR, f"sst_{d}.nc")
        if os.path.exists(sst_path):
            with xr.open_dataset(sst_path) as ds:
                s = ds["sst"].interp(lat=lat, lon=lon, method="nearest").load().values
        else:
            s = np.full_like(c.values, np.nan)
        sst_list.append(s)
    lon_g, lat_g = np.meshgrid(lon, lat)
    sea = ~globe.is_land(lat_g, lon_g) & ~((lat_g > 24.9) & (lon_g < 56.0))
    dates = [datetime.date(int(d[:4]), int(d[4:6]), int(d[6:])) for d in dates]
    return dates, lat_g, lon_g, sea, np.stack(chl_list), np.stack(sst_list)


def _nanmean(a, axis=0):
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        return np.nanmean(a, axis=axis)


def _nanmedian(a, axis=0):
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        return np.nanmedian(a, axis=axis)


@st.cache_data(show_spinner="Detecting blooms (chlorophyll anomaly)…")
def replay_detect(window, ratio, min_pixels, chl_min=3.0, base_days=30, lag=7):
    """
    Chlorophyll-anomaly bloom detection for every day:
      now      = mean of the last `window` days (fills cloud gaps)
      baseline = each pixel's own median over the `base_days` days ending `lag` days earlier
      bloom    = now >= chl_min AND now / baseline >= ratio, in clusters of >= min_pixels pixels,
                 ignoring the first ring of pixels next to land (turbid / mixed coastal pixels)
    """
    from scipy import ndimage
    dates, lat_g, lon_g, sea, chl, sst = load_replay()
    coast = ndimage.binary_dilation(~sea, iterations=1)
    T = len(dates)
    now_all, sst_all, anom_all, growth_all, flag_all = [], [], [], [], []
    for i in range(T):
        now = _nanmean(chl[max(0, i - window + 1):i + 1])
        s_now = _nanmean(sst[max(0, i - window + 1):i + 1])
        if i >= lag + 5:
            base = _nanmedian(chl[max(0, i - lag - base_days):i - lag])
        else:
            base = np.full_like(now, np.nan)
        with np.errstate(all="ignore"):
            anom = now / base
            prev = _nanmean(chl[max(0, i - 7 - window + 1):max(1, i - 7 + 1)]) if i >= 7 else np.full_like(now, np.nan)
            growth = (now - prev) / prev * 100
        flag = sea & ~coast & np.isfinite(anom) & (now >= chl_min) & (anom >= ratio)
        lab, n = ndimage.label(flag, structure=np.ones((3, 3)))
        if n:
            sizes = ndimage.sum(flag, lab, range(1, n + 1))
            flag = np.isin(lab, np.where(sizes >= min_pixels)[0] + 1)
        now_all.append(now); sst_all.append(s_now); anom_all.append(anom)
        growth_all.append(growth); flag_all.append(flag)
    return (np.stack(now_all), np.stack(sst_all), np.stack(anom_all),
            np.stack(growth_all), np.stack(flag_all))


def replay_frame(i, window, ratio, min_pixels):
    """Point table (valid sea pixels) for day i, with the bloom flag."""
    dates, lat_g, lon_g, sea, _, _ = load_replay()
    now, sst, anom, growth, flag = replay_detect(window, ratio, min_pixels)
    m = sea & np.isfinite(now[i])
    df = pd.DataFrame({"lat": np.round(lat_g[m], 3), "lon": np.round(lon_g[m], 3),
                       "chlorophyll": np.round(now[i][m], 2), "sst_temp": np.round(sst[i][m], 1),
                       "growth_rate_pct": np.round(growth[i][m], 1),
                       "anomaly": np.round(anom[i][m], 1), "bloom": flag[i][m]})
    return df.reset_index(drop=True)


@st.cache_data(show_spinner="Computing crisis timeline…")
def replay_timeline(window, ratio, min_pixels, plant_keys):
    """Nearest detected bloom (km) for every plant on every day."""
    dates, lat_g, lon_g, sea, _, _ = load_replay()
    flags = replay_detect(window, ratio, min_pixels)[4]
    plants = PLANTS[PLANTS["en"].isin(plant_keys)]
    rows = []
    for i, d in enumerate(dates):
        la, lo = lat_g[flags[i]], lon_g[flags[i]]
        for _, p in plants.iterrows():
            dist = float(haversine_km(p["lat"], p["lon"], la, lo).min()) if la.size else np.nan
            rows.append({"date": d, "en": p["en"], "dist": dist})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 4. Sidebar
# ---------------------------------------------------------------------------
st.sidebar.header(t("⚙️ مصدر البيانات والإعدادات", "⚙️ Data & Settings"))
MODE_SIM = t("محاكاة للعرض", "Simulated demo")
MODE_NASA = t("ملفات ناسا (NetCDF)", "NASA files (NetCDF)")
MODE_REPLAY = t("إعادة أزمة 2008 (بيانات ناسا)", "2008 crisis replay (NASA data)")
mode_options = [MODE_SIM, MODE_NASA] + ([MODE_REPLAY] if replay_available() else [])
mode = st.sidebar.radio(t("مصدر البيانات:", "Data source:"), mode_options)
SIMULATED = mode == MODE_SIM
REPLAY = mode == MODE_REPLAY

data_date = None
if REPLAY:
    r_dates = load_replay()[0]
    r_day = st.sidebar.select_slider(t("📅 تاريخ الرصد", "📅 Observation date"),
                                     options=r_dates, value=datetime.date(2008, 11, 16) if datetime.date(2008, 11, 16) in r_dates else r_dates[0],
                                     format_func=lambda d: d.strftime("%Y-%m-%d"))
    r_window = st.sidebar.slider(t("دمج آخر N أيام (لتجاوز الغيوم)", "Merge last N days (cloud gaps)"), 1, 8, 3)
    r_ratio = st.sidebar.slider(t("حد الشذوذ (أضعاف المعتاد)", "Anomaly threshold (× normal)"), 2.0, 6.0, 3.0, 0.5)
    r_minpix = st.sidebar.slider(t("أصغر حجم للبؤرة (بكسل ≈ 64 كم²)", "Minimum bloom size (pixels ≈ 64 km²)"), 1, 30, 10)
    df = replay_frame(r_dates.index(r_day), r_window, r_ratio, r_minpix)
    data_date = r_day.strftime("%Y-%m-%d")
elif SIMULATED:
    day = st.sidebar.slider(t("يوم المحاكاة (انجراف البؤر)", "Simulation day (bloom drift)"), 0, 5, 0)
    df = simulated_data(day)
else:
    chl_f = st.sidebar.file_uploader(t("ملف الكلوروفيل-أ (chlor_a) — مطلوب", "Chlorophyll-a file (chlor_a) — required"), type=["nc", "nc4"])
    prev_f = st.sidebar.file_uploader(t("ملف كلوروفيل سابق (لحساب النمو) — اختياري", "Earlier chlorophyll file (growth) — optional"), type=["nc", "nc4"])
    sst_f = st.sidebar.file_uploader(t("ملف حرارة سطح البحر (SST) — اختياري", "Sea surface temperature file — optional"), type=["nc", "nc4"])
    if chl_f is None:
        st.info(t("ارفع ملف كلوروفيل من OB.DAAC (PACE OCI أو MODIS-Aqua، المستوى 3) للبدء.",
                  "Upload a Level-3 chlorophyll file from OB.DAAC (PACE OCI or MODIS-Aqua) to start."))
        st.stop()
    try:
        df, data_date = nasa_data(chl_f.getvalue(), chl_f.name,
                                  prev_f.getvalue() if prev_f else None, prev_f.name if prev_f else None,
                                  sst_f.getvalue() if sst_f else None, sst_f.name if sst_f else None)
    except Exception as e:
        st.error(t(f"تعذّرت قراءة الملف: {e}", f"Could not read file: {e}"))
        st.stop()

df["risk_score"] = risk_score(df["chlorophyll"], df["sst_temp"], df["growth_rate_pct"])

regions = [t("كافة السواحل العمانية", "All Oman coastlines"),
           t("بحر عُمان (مسقط / صحار / صور)", "Sea of Oman (Muscat / Sohar / Sur)"),
           t("بحر العرب (الدقم / صلالة)", "Arabian Sea (Duqm / Salalah)")]
region = st.sidebar.selectbox(t("المنطقة:", "Region:"), regions)
min_risk = 0 if REPLAY else st.sidebar.slider(t("أدنى مؤشر خطورة (0–200):", "Minimum risk score (0–200):"), 0, 200, 70)
user_email = st.sidebar.text_input(t("بريد استلام التنبيهات:", "Alert email:"), value="")

# Region filter (applies to blooms AND plants)
if region == regions[1]:
    df_reg = df[df["lat"] >= REGION_SPLIT_LAT]
    plants = PLANTS[PLANTS["lat"] >= REGION_SPLIT_LAT]
    center, zoom = {"lat": 23.6, "lon": 58.2}, 6.3
elif region == regions[2]:
    df_reg = df[df["lat"] < REGION_SPLIT_LAT]
    plants = PLANTS[PLANTS["lat"] < REGION_SPLIT_LAT]
    center, zoom = {"lat": 18.5, "lon": 56.3}, 5.6
else:
    df_reg, plants = df, PLANTS
    center, zoom = {"lat": 21.0, "lon": 57.5}, 5.8

if REPLAY:   # replay uses the anomaly-based bloom detection
    hot = df_reg[df_reg["bloom"]].copy()
else:
    hot = df_reg[df_reg["risk_score"] >= min_risk].copy()

# ---------------------------------------------------------------------------
# 5. Proximity alerts
# ---------------------------------------------------------------------------
STATUS = {
    "critical": (t("🔴 حرج", "🔴 Critical"), t("حرج", "Critical"), (255, 205, 210)),
    "warning":  (t("🟡 تحذير", "🟡 Warning"), t("تحذير", "Warning"), (255, 243, 191)),
    "safe":     (t("🟢 آمن", "🟢 Safe"), t("آمن", "Safe"), (200, 238, 210)),
}

rows = []
for _, p in plants.iterrows():
    if hot.empty:
        dist, key = None, "safe"
    else:
        dist = float(haversine_km(p["lat"], p["lon"], hot["lat"].to_numpy(), hot["lon"].to_numpy()).min())
        key = "critical" if dist < CRITICAL_KM else ("warning" if dist < WARNING_KM else "safe")
    rows.append({"name": p["name"], "dist": None if dist is None else round(dist, 1), "key": key})
status_df = pd.DataFrame(rows)

critical_names = status_df.loc[status_df["key"] == "critical", "name"].tolist()
valid_d = status_df["dist"].dropna()
nearest = (f"{valid_d.min():.1f} " + t("كم", "km")) if not valid_d.empty else "—"

# ---------------------------------------------------------------------------
# 6. KPIs, banners
# ---------------------------------------------------------------------------
if SIMULATED:
    st.caption(t("⚠️ وضع العرض: البيانات المعروضة محاكاة واقعية وليست قراءات حقيقية. اختر «ملفات ناسا» لاستخدام بيانات الأقمار الصناعية.",
                 "⚠️ Demo mode: the data shown is a realistic simulation, not live readings. Choose “NASA files” to use satellite data."))
elif REPLAY:
    st.caption(t(f"🕰️ إعادة تاريخية لأزمة المد الأحمر 2008 — بيانات MODIS-Aqua الحقيقية من ناسا — التاريخ: {data_date}",
                 f"🕰️ Historical replay of the 2008 red tide — real NASA MODIS-Aqua data — date: {data_date}"))
else:
    st.caption(t(f"📡 بيانات ناسا — تاريخ الرصد: {data_date}", f"📡 NASA data — observation date: {data_date}"))

c1, c2, c3, c4 = st.columns(4)
c1.metric(t("البؤر النشطة", "Active hotspots"), len(hot))
c2.metric(t("أعلى كلوروفيل", "Max chlorophyll"), f"{df_reg['chlorophyll'].max():.1f} mg/m³" if not df_reg.empty else "—")
c3.metric(t("أعلى حرارة بحر", "Max sea temp"),
          f"{df_reg['sst_temp'].max():.1f} °C" if df_reg["sst_temp"].notna().any() else "—")
c4.metric(t("أقرب بؤرة لمحطة", "Nearest bloom to plant"), nearest)

email_ready = False
try:
    smtp_cfg = st.secrets["smtp"]
    email_ready = True
except Exception:
    smtp_cfg = None

if critical_names:
    st.error(t(f"🚨 إنذار حرج: بؤر طحالب على بعد أقل من {CRITICAL_KM} كم من: {'، '.join(critical_names)}",
               f"🚨 Critical alert: bloom within {CRITICAL_KM} km of: {', '.join(critical_names)}"))
    if user_email and email_ready:
        if st.button(t("📧 إرسال التنبيه بالبريد الآن", "📧 Send email alert now")):
            try:
                msg = EmailMessage()
                msg["Subject"] = "TideX Oman — Critical HAB alert"
                msg["From"] = smtp_cfg["sender"]
                msg["To"] = user_email
                msg.set_content("Critical bloom proximity:\n" + "\n".join(
                    f"- {r['name']}: {r['dist']} km" for _, r in status_df.iterrows() if r["key"] == "critical"))
                with smtplib.SMTP(smtp_cfg["host"], int(smtp_cfg.get("port", 587))) as s:
                    s.starttls()
                    s.login(smtp_cfg["user"], smtp_cfg["password"])
                    s.send_message(msg)
                st.success(t(f"تم إرسال التنبيه إلى {user_email}", f"Alert sent to {user_email}"))
            except Exception as e:
                st.warning(t(f"تعذّر الإرسال: {e}", f"Sending failed: {e}"))
    else:
        st.caption(t("📧 الإشعار بالبريد: يتطلب ضبط إعدادات SMTP وإدخال بريد في الشريط الجانبي (لم يُرسل أي بريد).",
                     "📧 Email alerts need SMTP settings and an address in the sidebar (no email was sent)."))

# ---------------------------------------------------------------------------
# 7. Map
# ---------------------------------------------------------------------------
st.subheader(t("🗺️ خريطة محطات التحلية وبؤر المد الأحمر", "🗺️ Desalination plants & bloom hotspots"))
labels = {"risk_score": t("مؤشر الخطورة", "Risk score"), "chlorophyll": t("كلوروفيل (mg/m³)", "Chl-a (mg/m³)"),
          "sst_temp": t("حرارة البحر °C", "SST °C"), "growth_rate_pct": t("النمو %", "Growth %"),
          "lat": t("خط العرض", "Lat"), "lon": t("خط الطول", "Lon"),
          "anomaly": t("الشذوذ (× المعتاد)", "Anomaly (× normal)")}

if hot.empty:
    fig = go.Figure()
else:
    color_col = "anomaly" if REPLAY else "risk_score"
    fig = px.scatter_map(hot, lat="lat", lon="lon", color=color_col, size="risk_score",
                         range_color=(r_ratio, 10) if REPLAY else (min_risk, 200), size_max=14, labels=labels,
                         center=center, zoom=zoom,
                         color_continuous_scale=["#9be7c4", "#ffe14d", "#c4001d"],
                         hover_data={"lat": ":.2f", "lon": ":.2f", "chlorophyll": True,
                                     "sst_temp": True, "growth_rate_pct": True, "risk_score": True,
                                     **({"anomaly": True} if REPLAY else {})})
fig.add_trace(go.Scattermap(lat=plants["lat"], lon=plants["lon"], mode="markers+text",
                            marker=dict(size=14, color="#1565c0"), text=plants["name"],
                            textposition="top right", name=t("محطات التحلية", "Desalination plants"),
                            hovertemplate="%{text}<extra></extra>"))
fig.update_layout(map=dict(style="open-street-map", center=center, zoom=zoom), uirevision=region,
                  height=560, margin=dict(r=0, t=0, l=0, b=0),
                  legend=dict(yanchor="top", y=0.99, xanchor="left", x=0.01))
st.plotly_chart(fig, width="stretch")

# ---------------------------------------------------------------------------
# 7b. Crisis timeline (replay mode only)
# ---------------------------------------------------------------------------
if REPLAY:
    st.markdown("---")
    st.subheader(t("📈 الخط الزمني للأزمة: متى كان TideX سيُنذر كل محطة؟",
                   "📈 Crisis timeline: when would TideX have alerted each plant?"))
    tl = replay_timeline(r_window, r_ratio, r_minpix, tuple(plants["en"]))
    tl["name"] = tl["en"].map(dict(zip(PLANTS["en"], PLANTS["name"])))

    fig_tl = px.line(tl, x="date", y="dist", color="name", markers=True,
                     labels={"date": t("التاريخ", "Date"), "dist": t("أقرب بؤرة (كم)", "Nearest bloom (km)"),
                             "name": t("المحطة", "Plant")})
    fig_tl.add_hrect(y0=0, y1=CRITICAL_KM, fillcolor="#c4001d", opacity=0.10, line_width=0)
    fig_tl.add_hrect(y0=CRITICAL_KM, y1=WARNING_KM, fillcolor="#ffc400", opacity=0.12, line_width=0)
    fig_tl.add_vline(x=r_day, line_dash="dash", line_color="#555")
    fig_tl.update_yaxes(range=[0, 250])
    fig_tl.update_layout(height=420, margin=dict(r=10, t=10, l=10, b=10))
    st.plotly_chart(fig_tl, width="stretch")

    first_rows = []
    for name, g in tl.groupby("name", sort=False):
        warn = g.loc[g["dist"] < WARNING_KM, "date"]
        crit = g.loc[g["dist"] < CRITICAL_KM, "date"]
        first_rows.append({
            t("المحطة", "Plant"): name,
            t("أول تحذير (< 50 كم)", "First warning (< 50 km)"): warn.min().strftime("%Y-%m-%d") if not warn.empty else "—",
            t("أول إنذار حرج (< 20 كم)", "First critical (< 20 km)"): crit.min().strftime("%Y-%m-%d") if not crit.empty else "—",
            t("المهلة بين التحذير والحرج (أيام)", "Lead time warning→critical (days)"):
                str((crit.min() - warn.min()).days) if not warn.empty and not crit.empty else "—",
        })
    first_df = pd.DataFrame(first_rows)
    if AR:
        first_df = first_df[first_df.columns[::-1]]
    st.dataframe(first_df, width="stretch", hide_index=True)
    st.caption(t("طريقة الكشف: شذوذ الكلوروفيل. البؤرة = كلوروفيل ≥ 3 mg/m³ وأعلى من المعتاد لنفس البكسل (وسيط 30 يوماً سابقة) بالحد المختار، في تجمّعات بالحجم المختار على الأقل، مع استبعاد الشريط الملاصق لليابسة. الأيام الغائمة تُملأ بمتوسط آخر N أيام.",
                 "Detection: chlorophyll anomaly. Bloom = chl ≥ 3 mg/m³ and above the pixel's own 30-day median by the chosen factor, in clusters of at least the chosen size, excluding the ring of pixels next to land. Cloudy days are filled with the mean of the last N days."))

# ---------------------------------------------------------------------------
# 8. Tables
# ---------------------------------------------------------------------------
st.markdown("---")
col1, col2 = st.columns(2)

plant_table = pd.DataFrame({
    t("المحطة", "Plant"): status_df["name"],
    t("أقرب بؤرة (كم)", "Nearest bloom (km)"): status_df["dist"].map(lambda d: "—" if d is None or pd.isna(d) else f"{d:.1f}"),
    t("الحالة", "Status"): status_df["key"].map(lambda k: STATUS[k][0]),
})
top = hot.sort_values("risk_score", ascending=False).head(6)[
    ["lat", "lon", "chlorophyll", "sst_temp", "growth_rate_pct", "risk_score"]].rename(columns=labels)
if AR:  # right-to-left column order
    plant_table = plant_table[plant_table.columns[::-1]]
    top = top[top.columns[::-1]]

with col1:
    st.subheader(t("🚨 حالة محطات التحلية", "🚨 Desalination plant status"))
    st.dataframe(plant_table, width="stretch", hide_index=True)
with col2:
    st.subheader(t("📊 البؤر الأعلى خطورة", "📊 Highest-risk hotspots"))
    st.dataframe(top, width="stretch", hide_index=True)

with st.expander(t("🔬 المنهجية ومصادر البيانات", "🔬 Methodology & data sources")):
    st.markdown(t(
        f"""
**مؤشر الخطورة (0–200)** = نقاط الكلوروفيل-أ (حتى 120، من 1 إلى 10 mg/m³) + نقاط حرارة سطح البحر (حتى 50، من 27 إلى 31°C) + نقاط النمو خلال 7 أيام (حتى 30، من 0 إلى 100%).

**مستويات الإنذار:** حرج أقل من {CRITICAL_KM} كم، تحذير من {CRITICAL_KM} إلى {WARNING_KM} كم، آمن أكثر من {WARNING_KM} كم. المسافة محسوبة بمعادلة Haversine.

**مصادر ناسا:** الكلوروفيل-أ من PACE OCI أو MODIS-Aqua (المستوى 3، أرشيف OB.DAAC)، وحرارة سطح البحر من GHRSST MUR (أرشيف PO.DAAC).

**قيود معروفة:** الكلوروفيل وحده لا يميّز الطحالب الضارة من غيرها، والغيوم تحجب القراءات الضوئية، والدقة تقل قرب الساحل. مواقع المحطات تقريبية.
""",
        f"""
**Risk score (0–200)** = chlorophyll-a points (up to 120, 1→10 mg/m³) + SST points (up to 50, 27→31 °C) + 7-day growth points (up to 30, 0→100 %).

**Alert levels:** Critical < {CRITICAL_KM} km, Warning {CRITICAL_KM}–{WARNING_KM} km, Safe > {WARNING_KM} km (Haversine distance).

**NASA sources:** chlorophyll-a from PACE OCI or MODIS-Aqua (Level-3, OB.DAAC); SST from GHRSST MUR (PO.DAAC).

**Known limits:** chlorophyll alone cannot tell harmful from harmless blooms; clouds block optical data; accuracy drops near the coast. Plant locations are approximate.
"""))

# ---------------------------------------------------------------------------
# 9. PDF report (Arabic RTL / English LTR, Readex Pro)
# ---------------------------------------------------------------------------
def build_pdf() -> bytes:
    pdf = FPDF()
    pdf.set_margins(18, 18, 18)
    pdf.add_page()
    pdf.add_font("Readex", "", FONT_REGULAR)
    pdf.add_font("Readex", "B", FONT_BOLD)
    pdf.set_text_shaping(use_shaping_engine=True, direction="rtl" if AR else "ltr")
    align = "R" if AR else "L"
    w = pdf.epw

    pdf.set_font("Readex", "B", 20)
    pdf.set_text_color(0, 90, 140)
    pdf.cell(w, 12, t("تقرير السلامة البحرية لمحطات التحلية", "Desalination Coastal Safety Report"),
             align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Readex", "", 14)
    pdf.set_text_color(90, 90, 90)
    pdf.cell(w, 9, "TideX Oman", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(6)

    pdf.set_text_color(20, 20, 20)
    if SIMULATED:
        source = t("محاكاة للعرض", "Simulated demo")
    elif REPLAY:
        source = t(f"إعادة أزمة 2008 — ناسا MODIS-Aqua ({data_date})", f"2008 replay — NASA MODIS-Aqua ({data_date})")
    else:
        source = t(f"بيانات ناسا ({data_date})", f"NASA data ({data_date})")
    lines = [
        t(f"تاريخ الإصدار: {datetime.date.today()}", f"Issued: {datetime.date.today()}"),
        t(f"مصدر البيانات: {source}", f"Data source: {source}"),
        t(f"المنطقة: {region}", f"Region: {region}"),
        t(f"عدد البؤر النشطة (مؤشر ≥ {min_risk}): {len(hot)}", f"Active hotspots (risk ≥ {min_risk}): {len(hot)}"),
        t(f"أقرب بؤرة لمحطة تحلية: {nearest}", f"Nearest bloom to a plant: {nearest}"),
    ]
    for ln in lines:
        pdf.multi_cell(w, 9, ln, align=align, new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)

    pdf.set_font("Readex", "B", 16)
    pdf.cell(w, 10, t("حالة محطات التحلية", "Plant status"), align=align, new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Readex", "", 14)

    headers = [t("المحطة", "Plant"), t("أقرب بؤرة (كم)", "Nearest bloom (km)"), t("الحالة", "Status")]
    widths = (90, 50, 34)
    if AR:
        headers, widths = headers[::-1], widths[::-1]
    head_style = FontFace(emphasis="BOLD", fill_color=(0, 90, 140), color=(255, 255, 255))
    with pdf.table(col_widths=widths, text_align="CENTER", line_height=10,
                   headings_style=head_style, padding=2) as table:
        row = table.row()
        for h in headers:
            row.cell(h)
        for _, r in status_df.iterrows():
            cells = [r["name"], "—" if r["dist"] is None or pd.isna(r["dist"]) else f"{r['dist']:.1f}",
                     STATUS[r["key"]][1]]
            colors = [None, None, STATUS[r["key"]][2]]
            if AR:
                cells, colors = cells[::-1], colors[::-1]
            row = table.row()
            for txt, col in zip(cells, colors):
                row.cell(txt, style=FontFace(fill_color=col) if col else None)

    pdf.ln(6)
    pdf.set_font("Readex", "", 12)
    pdf.set_text_color(110, 110, 110)
    pdf.multi_cell(w, 7, t(
        f"حرج: أقل من {CRITICAL_KM} كم — تحذير: {CRITICAL_KM} إلى {WARNING_KM} كم — آمن: أكثر من {WARNING_KM} كم. "
        "مؤشر الخطورة يجمع الكلوروفيل-أ وحرارة سطح البحر ومعدل النمو.",
        f"Critical: < {CRITICAL_KM} km — Warning: {CRITICAL_KM}–{WARNING_KM} km — Safe: > {WARNING_KM} km. "
        "The risk score combines chlorophyll-a, sea surface temperature and growth rate."), align=align)
    return bytes(pdf.output())


st.markdown("---")
st.download_button(t("📄 تحميل تقرير السلامة (PDF)", "📄 Download safety report (PDF)"),
                   data=build_pdf(), mime="application/pdf",
                   file_name=f"TideX_Report_{datetime.date.today()}.pdf")