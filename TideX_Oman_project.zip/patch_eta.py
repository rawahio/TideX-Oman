"""Adds OSCAR-currents drift direction + estimated arrival time to TideX replay mode."""
import shutil

P = "app.py"
s = open(P, encoding="utf-8").read()
if "plant_eta(" in s:
    raise SystemExit("Already patched.")
shutil.copy(P, "app_before_eta.py")

FUNCS = '''
CUR_DIR = os.path.join(BASE_DIR, "data", "currents_2008")


@st.cache_data
def load_currents(datestr):
    """OSCAR surface currents (m/s) for one day; coastal gaps filled from the nearest ocean cell."""
    from scipy import ndimage
    path = os.path.join(CUR_DIR, f"cur_{datestr}.nc")
    if not os.path.exists(path):
        return None
    with xr.open_dataset(path) as ds:
        u, v = ds["u"].values.astype(float), ds["v"].values.astype(float)
        lat, lon = ds["lat"].values.astype(float), ds["lon"].values.astype(float)
    ok = np.isfinite(u) & np.isfinite(v)
    if not ok.any():
        return None
    idx = ndimage.distance_transform_edt(~ok, return_distances=False, return_indices=True)
    return lat, lon, u[tuple(idx)], v[tuple(idx)]


def plant_eta(plat, plon, la, lo, cur):
    """Hours until a bloom pixel drifts to within CRITICAL_KM of the plant, and drift speed
    of the nearest bloom pixel toward the plant (m/s, negative = moving away)."""
    clat, clon, U, V = cur
    ii = np.clip(np.round((la - clat[0]) / (clat[1] - clat[0])).astype(int), 0, len(clat) - 1)
    jj = np.clip(np.round((lo - clon[0]) / (clon[1] - clon[0])).astype(int), 0, len(clon) - 1)
    u, v = U[ii, jj], V[ii, jj]
    dx = (plon - lo) * 111.32 * np.cos(np.radians(plat))
    dy = (plat - la) * 110.57
    dist = haversine_km(plat, plon, la, lo)
    with np.errstate(all="ignore"):
        toward = (u * dx + v * dy) / np.hypot(dx, dy)
        hours = np.where(dist <= CRITICAL_KM, 0.0,
                         np.where(toward > 0.01, (dist - CRITICAL_KM) * 1000 / toward / 3600, np.inf))
    return float(np.min(hours)), float(toward[int(np.argmin(dist))])


# ---------------------------------------------------------------------------
# 4. Sidebar'''

ETA_BLOCK = '''status_df = pd.DataFrame(rows)

ETA_ON = False
if REPLAY and not hot.empty:
    _cur = load_currents(r_day.strftime("%Y%m%d"))
    if _cur is not None:
        ETA_ON = True
        eta_txt, drift_txt = [], []
        for _, p in plants.iterrows():
            h, vt = plant_eta(p["lat"], p["lon"], hot["lat"].to_numpy(), hot["lon"].to_numpy(), _cur)
            if h == 0:
                eta_txt.append(t("وصلت الساحل", "At the coast"))
            elif np.isinf(h):
                eta_txt.append("—")
            elif h < 48:
                eta_txt.append(t(f"{h:.0f} ساعة", f"{h:.0f} h"))
            else:
                eta_txt.append(t(f"{h / 24:.1f} يوم", f"{h / 24:.1f} days"))
            if vt > 0.01:
                drift_txt.append(t(f"⬆ تقترب ({vt:.2f} م/ث)", f"⬆ approaching ({vt:.2f} m/s)"))
            elif vt < -0.01:
                drift_txt.append(t(f"⬇ تبتعد ({-vt:.2f} م/ث)", f"⬇ moving away ({-vt:.2f} m/s)"))
            else:
                drift_txt.append(t("ثابتة تقريباً", "almost still"))
        status_df["eta_txt"] = eta_txt
        status_df["drift_txt"] = drift_txt'''

TABLE_ADD = '''if ETA_ON:
    plant_table[t("انجراف أقرب بؤرة (تيارات OSCAR)", "Nearest bloom drift (OSCAR currents)")] = status_df["drift_txt"].values
    plant_table[t("الوقت المتوقع للوصول (< 20 كم)", "Estimated arrival (< 20 km)")] = status_df["eta_txt"].values
if AR:  # right-to-left column order'''

CAPTION = '''    st.dataframe(plant_table, width="stretch", hide_index=True)
    if ETA_ON:
        st.caption(t("الانجراف والوقت المتوقع للوصول محسوبان من تيارات سطح البحر OSCAR من ناسا (PO.DAAC) لنفس اليوم: سرعة التيار باتجاه المحطة، ثم الزمن اللازم لقطع المسافة حتى 20 كم منها.",
                     "Drift and arrival time use NASA OSCAR surface currents (PO.DAAC) for the same day: current speed toward the plant, then the time to cover the distance to 20 km from it."))
    elif REPLAY:
        st.caption(t("بيانات التيارات متوفرة لأيام 22–25 أكتوبر و12–16 نوفمبر 2008 لعرض الانجراف والوقت المتوقع للوصول.",
                     "Current data is available for 22–25 Oct and 12–16 Nov 2008 to show drift and arrival time."))'''

edits = [
    ("\n# ---------------------------------------------------------------------------\n# 4. Sidebar", FUNCS),
    ("status_df = pd.DataFrame(rows)", ETA_BLOCK),
    ("if AR:  # right-to-left column order", TABLE_ADD),
    ('    st.dataframe(plant_table, width="stretch", hide_index=True)', CAPTION),
]
for old, new in edits:
    if s.count(old) != 1:
        raise SystemExit(f"Could not find the place to edit: {old[:50]!r}. app.py was not changed.")
    s = s.replace(old, new)

open(P, "w", encoding="utf-8").write(s)
print("OK - app.py updated (old version saved as app_before_eta.py)")