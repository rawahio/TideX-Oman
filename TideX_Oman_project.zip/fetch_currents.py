import os
import re
import shutil
import tempfile

import earthaccess
import numpy as np
import xarray as xr

LAT_MIN, LAT_MAX = 16.0, 26.6
LON_MIN, LON_MAX = 53.0, 60.6
OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "currents_2008")
SHORT_NAME = "OSCAR_L4_OC_FINAL_V2.0"
RANGES = [("2008-10-22", "2008-10-25"), ("2008-11-12", "2008-11-16")]


def subset(src, dst):
    with xr.open_dataset(src) as ds:
        latv = ds["lat"] if "lat" in ds.variables else ds["latitude"]
        lonv = ds["lon"] if "lon" in ds.variables else ds["longitude"]
        lat, lon = latv.values, lonv.values
        li = np.where((lat >= LAT_MIN) & (lat <= LAT_MAX))[0]
        lo = np.where((lon >= LON_MIN) & (lon <= LON_MAX))[0]
        out = {}
        for var in ("u", "v"):
            da = ds[var].squeeze(drop=True).isel({latv.dims[0]: li, lonv.dims[0]: lo})
            da = da.transpose(latv.dims[0], lonv.dims[0]).load().values.astype("f4")
            out[var] = (("lat", "lon"), da)
        xr.Dataset(out, coords={"lat": lat[li].astype("f4"), "lon": lon[lo].astype("f4")}).to_netcdf(dst)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    auth = earthaccess.login(strategy="netrc")
    if not auth.authenticated:
        raise SystemExit("Login failed.")
    wanted = {}
    for start, end in RANGES:
        print(f"=== searching {SHORT_NAME} {start} -> {end}")
        for g in earthaccess.search_data(short_name=SHORT_NAME, temporal=(start, end)):
            for link in g.data_links():
                m = re.search(r"_(\d{8})\.nc$", link)
                if m and start.replace("-", "") <= m.group(1) <= end.replace("-", "") and m.group(1) not in wanted:
                    wanted[m.group(1)] = g
    print(f"found {len(wanted)} daily files")
    for i, (date, granule) in enumerate(sorted(wanted.items()), 1):
        dst = os.path.join(OUT_DIR, f"cur_{date}.nc")
        if os.path.exists(dst):
            print(f"[{i}/{len(wanted)}] {date} already done")
            continue
        tmp = tempfile.mkdtemp()
        try:
            paths = earthaccess.download([granule], local_path=tmp, show_progress=False)
            src = next(str(p) for p in paths if str(p).endswith(".nc"))
            subset(src, dst)
            print(f"[{i}/{len(wanted)}] {date} saved ({os.path.getsize(dst) // 1024} KB)")
        except Exception as e:
            print(f"[{i}/{len(wanted)}] {date} FAILED: {e}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    print(f"\nDone. Files are in: {OUT_DIR}")


if __name__ == "__main__":
    main()